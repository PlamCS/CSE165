#pragma

void createArray(int size, int*& array);
void printArray(int size, int* array);
