#include <string>
#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

int main()
{
	vector<string> v;
	ifstream in( "file.txt" );
	
	// ...
		
	return 0;
}